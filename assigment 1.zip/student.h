
#include <iostream>
using namespace std;
class student
{	private:
int scr;
	int roll,scre[5];
	int sum=0;
	string name;
	public:
		int rol();
		int score();
		int nam();
		student();


};

