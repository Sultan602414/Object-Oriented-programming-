#include "student.h"
#include <iostream>
using namespace std;
int main(){
	student st1,st2;
	st1.nam();
st1.rol();
st1.score();

	st2.nam();
    st2.rol();
    st2.score();

}
