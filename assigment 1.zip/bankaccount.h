#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H
#include<iostream>
using namespace std;
class bankaccount
{	private:
	int acc_no,balance,get,amount;
	string name;


	public:
	bankaccount ( );
	void acount();
	void display();


};

#endif
