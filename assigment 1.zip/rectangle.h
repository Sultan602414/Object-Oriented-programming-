#ifndef RECTANGLE_H
#define RECTANGLE_H
#include<iostream>
using namespace std;
class rectangle
{	private:
	int width,length;
	public:
	int area();
	int perimeter();
	rectangle();
	rectangle(int ,int );
};

#endif

