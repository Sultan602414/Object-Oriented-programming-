#include "bankaccount.h"
#include<iostream>
#include<stdlib.h>
using namespace std;
int main(){
	int ac_no,balance;
	string name;
	const int num = 3;
//	bankaccount person1;
	bankaccount one();
    bankaccount two();
    bankaccount three();
   bankaccount arr[num] = {one,two,three};
    for (int i=0;num>i;i++)
    {
        arr[i].acount();
        arr[i].display();
    }

//	person1.acount();
//	person1.display();



}
