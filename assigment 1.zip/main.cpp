#include<iostream>
#include "rectangle.h"
using namespace std;
int main(){
    int len=3,wid=4;

	rectangle rect_1 ,rec3(len,wid) ;



	rect_1.area();
	rect_1.perimeter();
    rectangle rect_2;
	rect_2.area();
	rect_2.perimeter();

}
