#include <iostream>
using namespace std;
void func(int *a,int*b ){
	*a=*a+ *b;
	*b=*a-*b;
	*a=*a-*b;
	
	cout<<"a= "<<*a<< " b= "<<*b;
}
int main()
{
	int a;
	int b;
	cout<<"ENTER VALUE OF A and B"<<endl;
	cin>>a>>b;
	system("CLS");
	cout<<"BEFORE"<<endl;	
	cout<<"a= "<<a<< " b= "<<b<<endl;
	cout<<"AFTER"<<endl;
	func(&a,&b);
	
	
	
	

	

}