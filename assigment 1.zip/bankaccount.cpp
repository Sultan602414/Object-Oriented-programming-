#include "bankaccount.h"
#include<iostream>
using namespace std;
bankaccount :: bankaccount(){



	cout<<"ENTER THE  ACOUNT NAME: ";
	cin>>name;
	cout<<"ENTER THE  ACOUNT NUMBER: ";
	cin>>acc_no;
	cout<<"ENTER THE  ACOUNT balance: ";
	cin>>balance;
}

void bankaccount :: acount( ){

	cout<<"ENTER '1' to withdraw '0' to deposit "<<endl;
	cin>>get;
	if(get==1){
		cout<<"ENTER the amount to withdraw  "<<endl;
		cin>>amount;
		if(amount <= balance){
			balance=balance-amount;
		}
		else if(amount > balance){
			cout<<"!!!!!! you DONT HAVE ENOUGH AMOUNT TO WITHDRAW  "<<endl;
		}
	}
	else if(get==0){
    cout<<"ENTER the amount to withdraw  "<<endl;
		cin>>amount;
		balance=balance+amount;
	}
	else{
		cout<<"ANNI DIA MZAK AY "<<endl;
	}
}
void bankaccount :: display(){
	cout<<"ACOUNT NAME: "<<	name<<endl;
	cout<<" ACOUNT NUMBER: "<<acc_no<<endl;
	cout<<" ACOUNT BALANCE: "<<balance<<endl;
}
