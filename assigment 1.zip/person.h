#ifndef PERSON_H
#define PERSON_H
#include<iostream>
using namespace std;
class person
{	private:
	string name;
	int age;
	
	public:
		person();
		person(string,int);
	
};

#endif