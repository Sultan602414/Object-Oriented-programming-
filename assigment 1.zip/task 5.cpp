#include <iostream>
using namespace std;

class StaticArray
{
public:
    int array[4];
    int *p = array;
    StaticArray();
    StaticArray(StaticArray &other); // Deep copy constructor
    void print();
};

StaticArray::StaticArray()
{
    for (int i = 0; i < 4; i++)
    {
        array[i] = rand() % 10;
    }
}

// Deep copy constructor
StaticArray::StaticArray(StaticArray &other)
{
    for (int i = 0; i < 4; i++)
    {
        array[i] = other.array[i];
    }
}

void StaticArray::print()
{
    for (int i = 0; i < 4; i++)
    {
        cout << p[i] << " ";
    }
}

int main()
{
    StaticArray sa1;
    cout << "Original Array: \n";
    sa1.print();
    StaticArray sa2 = sa1; // Shallow copy
    cout << "\nShallow Copy: " << endl;
    sa2.print();
    
    // Modify the shallow copy
    sa1.p[3] = 5;
    
    cout << "\n\nAfter Modification in original array: \nDeep Copy: \n";
    sa2.print();
    cout << "\nOriginal Array: " << endl;
    sa1.print();
    
    // Create a new deep copy
    StaticArray sa3 = sa1;
    
    // Modify the deep copy
    sa1.p[1] = 7;
    
    cout << "\n\nAfter Modification in original array: \nShalow Copy: \n";
    sa3.print();
    cout << "\nOriginal Array: " << endl;
    sa1.print();
}