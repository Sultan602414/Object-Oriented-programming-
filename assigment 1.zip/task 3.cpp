#include "person.h"
#include<iostream>
using namespace std;
int main(){
	string name;
	int age;
	person p1(name,age);
	person p2;
	
}