#include "person.h"
#include<iostream>
using namespace std;

 person :: person(){
	cout<<"ENTER THE NAME OF PERSON: "<<endl;
	cin>>name;
	cout<<"ENTER THE age OF PERSON: "<<endl;
	cin>>age;
	cout<<"THE AGE OF "<<name<<" is "<< age<<endl;	
} 
person :: person(string name,int age){
	cout<<"ENTER THE NAME OF PERSON: "<<endl;
	cin>>name;
	cout<<"ENTER THE age OF PERSON: "<<endl;
	cin>>age;
	cout<<"THE AGE OF "<<name<<" is "<< age<<endl;
}