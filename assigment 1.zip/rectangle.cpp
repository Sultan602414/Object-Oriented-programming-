#include "rectangle.h"
#include<iostream>
using namespace std;
rectangle :: rectangle(){
    cout<<"ENTER THE LENGTH OF ThE RECTANGLE: "<<endl;
	cin>>length;
	cout<<"ENTER THE width OF ThE RECTANGLE: "<<endl;
	cin>>width;
}
rectangle ::rectangle(int length,int width){
cout<<"THE AREA OF THE RECTANGLE IS: "<<length*width<<endl;
cout<<"THE perimter OF THE RECTANGLE IS: "<<(2*length)+(2*width)<<endl;
}


rectangle ::  area(){


	cout<<"THE AREA OF THE RECTANGLE IS: "<<length*width<<endl;
}
rectangle ::  perimeter(){


	cout<<"THE perimter OF THE RECTANGLE IS: "<<(2*length)+(2*width)<<endl;
}
