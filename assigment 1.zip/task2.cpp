#include<iostream>
#include "rectangle.h"
using namespace std;
int main(){
	rectangle rect_1 ;



	rect_1.area();
	rect_1.perimeter();
    rectangle rect_2;
	rect_2.area();
	rect_2.perimeter();
}
