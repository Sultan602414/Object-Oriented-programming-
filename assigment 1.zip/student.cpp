#include "student.h"
#include <iostream>
using namespace std;
student :: student(){
	cout<<"ENTER THE NAME OF STUDENT"<<endl;
	cin>>name;
	cout<<"ENTER THE age OF STUDENT"<<endl;
	cin>>roll;

	cout<<"ENTER THE score OF five subject"<<endl;

	for(int i=0;i<5;i++){
		cin>>scr;
		scre[i]=scr;
	}

}
student :: nam(){
	cout<<"the name of student is "<<name<<endl;
}
student :: rol(){
	cout<<"the roll no of student is "<<roll<<endl;
}
student :: score(){

    for(int i=0;i<5;i++){
		sum=sum+ scre[i];
	}
	cout<<"THE AVG OF STUDENT SCORES IS "<<sum/5;
	cout<<endl;
}
