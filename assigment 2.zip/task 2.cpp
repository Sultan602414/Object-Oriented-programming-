#include<iostream>
using namespace std;
class basicinfo{
	public: 
	string name,gender;
	int emp_id;
	protected:
		void getbasicinfo(){
			cout<<"ENTER THE employe NAME: ";
			cin>>name;
			cout<<endl;
			cout<<"ENTER THE employe ID : ";
			cin>>emp_id;
			cout<<endl;
			cout<<"ENTER THE employe gender: ";
			cin>>gender;
			cout<<endl;
		}
	
};
class deptinfo{
	public:
	string	dep_name,dep_work;
	int time;
	protected:
		void getdepinfo(){
			cout<<"ENTER THe dpARTmenT name :";
			cin>>dep_name;
			cout<<endl;
			cout<<"ENTER THe dpARTmenT work :";
			cin>>dep_work;
			cout<<endl;
			cout<<"ENTER THe time to complete :";
			cin>>time;
			cout<<endl;
		}
		
};
class employe: public basicinfo , public deptinfo {
	public:
		void getempinfo(){
		getbasicinfo();
		getdepinfo();
		}
		void print_info(){
			cout<<"EMPLOYEE NAME IS: "<<name<<endl;
			cout<<"EMPLOYEE id IS: "<<emp_id<<endl;
			cout<<"EMPLOYEE GENDER IS : "<<gender<<endl;
			cout<<"EMPLOYE department NAME IS: "<<dep_name<<endl;
			cout<<"EMPLOYEE department work IS: "<<dep_work<<endl;
			cout<<"TIME TO COMPLETE THE WORK "<<time<<endl;
		}
	
};
int main(){
	employe emp1;
	emp1.getempinfo();
	emp1.print_info();
}
