#include<iostream>
using namespace std;
class filmstreaming {
	private:
		double imbd[5];
		string name[5];
		string nam;
		string genre[5];
		int x;
		
	public:
		filmstreaming(){
			name[0]="JAWAN";
			name[1]="KGF";
			name[2]="PK";
			name[3]="TIGER";
			name[4]="PATHAN";
			
			imbd[0]=3.4;
			imbd[1]=5;
			imbd[2]=4;
			imbd[3]=4.5;	
			imbd[4]=3;
			
			genre[0]="crime";
			genre[1]="action";
			genre[2]="funny";
			genre[3]="thriller";
			genre[4]="adventures";
				
		}
		void myservices(){
			cout<<"ENTER '1' to search movie by name: "<<endl;
			cout<<"ENTER '2' to find highest rated movie along with its details "<<endl;
			cout<<"ENTER '3' to  see the list of all movies "<<endl;
			cin>>x;
			if(x==1){
				cout<<"ENTER THE NAME of movie  TO SERCH: ";
				cin>>nam;
				for (int i=0;i<5;i++){
					if (name[i]==nam){
						cout<<"YES WE HVE THIS MOVIE :"<<endl;
						exit(1);
					}		
				}
				cout<<"sorry we do not have this movie: "<<endl;
			}
			else if (x==2){
				cout<<"THE HIGHEST RATED MOVIE IS "<<name[1]<<" which is a "<<genre[1]<<" moviev with imbd rating "<<imbd[1]<<endl;
			}
			else if (x==3){
				for(int i=0;i<5;i++){
					cout<<name[i]<<endl;
				}
			}
			else {
				cout<<"WRONG INPUT: !!!!!!!!!!";
			}
		}
		
};
int main(){
	filmstreaming c1;
	c1.myservices();
}
