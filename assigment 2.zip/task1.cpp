#include<iostream>
using namespace std;

class parent
{
public:
	string name, DOB;
	int age;
	parent()
	{
		name = "sardar jatt";
		DOB = "9 jan 1888";
		age = 50;
	}
};

class Grandparent : parent
{
public:
	string firstname, address;
	Grandparent()
	{
		firstname = "mola jatt";
		address = "tehsil gardaspor";
	}
	void print()
	{
		cout<<name<<endl<<DOB<<endl<<age;
		cout<<endl<<firstname<<endl<<address;
	}
};

int main()
{
	parent *ptr1;
	Grandparent *ptr2;
	ptr2 = (Grandparent *) ptr1;
	Grandparent gp;
	gp.print();
}
