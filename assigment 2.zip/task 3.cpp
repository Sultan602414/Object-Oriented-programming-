#include<iostream>
using namespace std;
class student{
	public:
	int student_number;
	string student_name;
	double student_average;
	
	student(){
		student_number=1;
		student_name="SUTAN";
		student_average = 3.23;
	}
	
	void get_student_info(){
		char x;
		cout<<"IF YOU WANT TO UPDATE YOUR STUDENT INFO PRESS 'Y' and any other key if you want to go with the default one: ";
		cin>>x;
		if(x=='Y' || x=='y'){
			cout<<"ENTER THE STUDENT NUMBER: ";
			cin>>student_number;
			cout<<"ENTER THE STUDENT NAME : ";
			cin>>student_name;
			cout<<"ENTER THE STUDENT AVG: ";
			cin>>student_average;
		}
		else{
			cout<<"ok!!!"<<endl;
		}	
	}
	void print1(){
		cout<<" THE STUDENT NUMBER: "<<student_number<<endl;
		cout<<" THE STUDENT NAME : "<<student_name<<endl;
		cout<<" THE STUDENT AVG: "<<student_average<<endl;
	}
};
class graduate_student : public student{
	public:
	int level,year;
	graduate_student(){
		level=1;
		year=1;
	}
	protected:
	void  get_info(){
			
			char x;
		cout<<"IF YOU WANT TO UPDATE YOUR GRADUATE INFO PRESS 'Y' and any other key if you want to go with the default one: ";
		cin>>x;
		if(x=='Y' || x=='y'){
			cout<<"ENTER THE STUDENT level: ";
			cin>>level;
			cout<<"ENTER THE STUDENT year : ";
			cin>>year;
		}
		else{
			cout<<"ok!!!"<<endl;
		}	
		}
		
		void print2(){
		cout<<" THE STUDENT level: "<< level<<endl;
		cout<<" THE STUDENT year : "<<year<<endl;
	}
};
class master : public graduate_student{
	public: 
	int newid;
	master(){
	newid=2;
	}
	
	void get(){
		
	get_info();
	char x;
		cout<<"IF YOU WANT TO UPDATE YOUR MASTERS INFO PRESS 'Y' and any other key if you want to go with the default one: ";
		cin>>x;
		if(x =='Y' || x=='y'){
			cout<<"ENTER THE STUDENT new id: ";
			cin>>newid;
		}
		else{
			cout<<"ok!!!"<<endl;
		}
	}
	
	
	void print(){
		
		print2();
		cout<<" THE STUDENT NEW ID: "<<newid<<endl;
	}	
};
int main(){
	student st;
	master ms;
	st.get_student_info();
	st.print1();
	ms.get();
	ms.print();
	
}
