#include<iostream>
using namespace std;
class MediaItem{
	public:
		string tittle,arr1[20],arr3[20];
		int year,count=3,arr2[20],type,arr4[20],count2=3;
		virtual void displayinfo(){	
		} 
		 int mediatype(){
			cout<<"WHAT IS THE TYPE OF MEDIA \n press 1 FOR BOOK \n press 2 FOR MOVIE \n";
			cin>>type;
			return type;
		}
};
class book: public MediaItem{
	public:
		book(){
			arr1[0]="LIFE";
			arr1[1]="GREAT_EXPECTATIONS";
			arr1[2]="PRISONER";
			arr2[0]=1920;
			arr2[1]=1822;
			arr2[2]=1990;
		}
		void book_adding(){
			int x;
			cout<<"HOW MANY BOOKS YOU WANT TO ADD TO LIBRARY :";
			cin>>x;
			for(int i=0;i<x;i++){
			cout<<"ENTER tHE NAME OF BOOK"<<endl;
			cin>> tittle;
			cout<<"ENTER tHE YEAR OF BOOK"<<endl;
			cin>> year;
			arr1[count]=tittle;
			arr2[count]=year;
			count++;
			}
		}
		void displayinfo(){
			for(int i=0;i<count;i++){
				cout<<arr1[i]<<" published in "<<arr2[i]<<endl;
			}
		}
		
};
class movie: public MediaItem{
	public:
		movie(){
			arr3[0]="HARRY_POTTER";
			arr3[1]="PURGE";
			arr3[2]="Xman";
			arr4[0]=2009;
			arr4[1]=2012;
			arr4[2]=2015;
		}
		void movie_adding(){
			int x;
			cout<<"HOW MANY MOVIES YOU WANT TO ADD TO LIBRARY :";
			cin>>x;
			for(int i=0;i<=x;i++){
			cout<<"ENTER tHE NAME OF MOVIE"<<endl;
			cin>> tittle;
			cout<<"ENTER tHE YEAR OF MOVIE"<<endl;
			cin>> year;
			arr3[count2]=tittle;
			arr4[count2]=year;
			count2++;
			}
		}
		void displayinfo(){
			for(int i=0;i<count2;i++){
				cout<<arr3[i]<<" of "<<arr4[i]<<endl;
			}
		}
};
int main(){
	int y,z,r,x;
	MediaItem *ptr;
	ptr= new book;
	book bk;
	movie mv; 
	ptr->mediatype();
	if(ptr->type==1){
		ptr=& bk;
		cout<<"           you want to add book or want to see our collection\npress 1 to ADD \npress 2 to see our collection\n";
		cin>>y;
		if(y==1){
		bk.book_adding();
		 cout<<"YOU WANT TO SEE ALL COLLECTION: \n 1 YES \n 2 NO \n";
        cin>>x;
        if(x==1){
        	ptr->displayinfo();
		}
	}
	else if(y==2){
		ptr->displayinfo();
	}
	}
	if(ptr->type==2){
		ptr=&mv;
		cout<<"           you want to add MOVIE or want to see our collection\npress 1 to ADD \npress 2 to see our collection\n";
		cin>>z;
		if(z==1){
        mv.movie_adding();
        cout<<"YOU WANT TO SEE ALL COLLECTION: \n 1 YES \n 2 NO \n";
        cin>>r;
        if(r==1){
        	ptr->displayinfo();
		}
    }
	else if(z==2){
    	ptr->displayinfo();
	}
	}
}
