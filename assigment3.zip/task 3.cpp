#include <iostream>
using namespace std;
class account{
	public:
		int acc_no,balance,amount;
		account(){
			balance =100000;
			cout<<"ENTER THE ACOUNT NO: "<<endl;
			cin>>acc_no;
		}	
	virtual void withdraw (){
	 	
	}
};
class saving_account: public account{
	public:
		int savings=200,x;
		void withdraw(){
			cout<<"IN SAVING ACCOUNT FOR EVERY  WTHDRAW 100 will be deducted as savings: \n";
			cout<<"ENTER THE AMMOUNT YOU WANT TO WITHDRAW: \n";
			cin>>amount;
				if(amount<balance){
			savings = amount - 100;	
			balance=balance - savings -amount;
		}else{
			cout<<"out of balance:";
		}
		cout<<"IF you want to see the current savings press 1\n";
		cout<<"IF you want to see the current balance press 2\n";
		cin>>x;
		if(x==1){
		cout<<"the current savings are "<<savings<<endl;
	}
	else if(x==2){
		cout<<"the current balance is "<<balance<<endl;
	}
		}
};
class current_account: public account{
	public:
			void withdraw(){
			cout<<"ENTER THE AMMOUNT YOU WANT TO WITHDRAW: \n";
			cin>>amount;
				if(amount<balance){	
			balance=balance - amount;
		}else{
			cout<<"out of balance:\n";
		}
		}
};
int main (){
	int a;
	account *ptr;
	cout<<"1 saving account:\n2 current account: \n";
	cin>>a;
	if(a==1){
		saving_account sv;
		ptr=&sv;
        ptr->withdraw();
	}else if(a==2){
		current_account cu;		
		ptr=&cu;
		ptr->withdraw();
	}

	
	
	
}
