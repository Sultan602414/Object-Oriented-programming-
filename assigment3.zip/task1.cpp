#include<iostream>
using namespace std;

class vehicle {
public:
    int vehicle_type;
    int rate;

    virtual void rental_rate() = 0;

    int vehicletype() {
        cout << "WHAT IS THE TYPE OF VEHICLE: \npress 1 for bike \npress 2 for car " << endl;
        cin >> vehicle_type;
        return vehicle_type;
    }
};

class bike : public vehicle {
public:
    void rental_rate() override {
        rate = 1000;
        cout << "THE RENT OF BIKE FOR 1 HOUR IS " << rate << endl;
    }
};

class car : public vehicle {
public:
    void rental_rate() override {
        rate = 5000;
        cout << "THE RENT OF CAR FOR 1 HOUR IS " << rate << endl;
    }
};

int main() {
    vehicle *vh[3];

   // vh[0] = new vehicle; // You need to create an instance of vehicle or use derived classes directly
  vh[0] = new bike;
    vh[0]->vehicletype();

    if (vh[0]->vehicle_type == 2) {
        vh[1] = new car;
        vh[1]->rental_rate();
    }

    if (vh[0]->vehicle_type == 1) {
        vh[2] = new bike;
        vh[2]->rental_rate();
    }

    // Don't forget to delete allocated memory
    delete vh[0];
    delete vh[1];
    delete vh[2];

    return 0;
}

