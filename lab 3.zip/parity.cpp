#include "parity.h"

parity::parity()
{

}
void parity::put()
{
    for(int i=0;i<sizee;i++)
    {

        cout << "Enter Number:";
        cin >> user;
        if(user==-1)
        {
            break;
        }
        arrays[i] = user;
        sizee++;
    }
}

void parity::printing()
{
    for(int i=0;i<(sizee-1);i++)
    {
        cout << arrays[i] << " ";
    }
    cout << endl;
}
void parity:: delet(){
	char chr;
	cout<<"if you want to delete a number from list PRESS d ";
	cin>>chr;
	if(chr=='d'||chr=='D'){
		arrays[sizee-2]=0;
	}
}

bool parity::test()
{
    if((sizee-1)%2==0)
    {
    return true;
    }
    else
    {
       return false;
    }
}
