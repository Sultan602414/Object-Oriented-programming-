#include "task1.h"
#include <iostream>
using namespace std;
task1::task1(){
	temp=15;
}

  void task1 :: warmer(){
	 temp=temp+5;
	 cout<<temp;	
}
  void task1 :: cooler(){
    temp=temp-5;	
	cout<<temp;
}