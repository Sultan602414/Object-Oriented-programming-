#include <iostream>
#include "student.h"
using namespace std;

int main()
{
    student st;
    cout << "Grades Array : "<< endl;
    for(int i=0;i<7;i++)
    {
        cout << st.grades[i]<<" ";
    }
    cout<<endl;
    cout << "Student names Array : "<< endl;
    for(int i=0;i<4;i++)
    {
        cout << st.names[i]<<" ";
    }
    cout << endl<< "Adress using Pointer:" << st.pointr;
    cout << endl<< "Normal int value:" << st.a<<endl;
    cout << endl << endl << "Shallow Copy Of Both Array"<<endl<<endl;
    student s0=st;
    cout << "Grades Array : "<< endl;
    for(int i=0;i<7;i++)
    {
        cout << s0.grades[i]<<" ";
    }
    cout<<endl;
    cout << "Student names Array : "<< endl;
    for(int i=0;i<4;i++)
    {
        cout << s0.names[i]<<" ";
    }
    cout << endl<< "Adress using Pointer:" << s0.pointr;
    cout << endl<< "Normal int value:" << s0.a<<endl;
    st.grades[1]=10;
    st.grades[4]=99;
    st.a=222;
    st.names[1]="john";

    cout << endl<<endl<<"-----------------After Editing Both Arrays-----------------"<<endl<<endl;

    cout << "Grades Array : "<< endl;
    for(int i=0;i<7;i++)
    {
        cout << st.grades[i]<<" ";
    }
    cout<<endl;
    cout << "Student names Array : "<< endl;
    for(int i=0;i<4;i++)
    {
        cout << st.names[i]<<" ";
    }
    cout << endl<< "Adress using Pointer:" << st.pointr;
    cout << endl<< "Normal int value:" << st.a<<endl;
    cout << endl << endl << "Shallow Copy Of Both Array"<<endl<<endl;
    //student s0=st;
    cout << "Grades Array : "<< endl;
    for(int i=0;i<7;i++)
    {
        cout << s0.grades[i]<<" ";
    }
    cout<<endl;
    cout << "Student names Array : "<< endl;
    for(int i=0;i<4;i++)
    {
        cout << s0.names[i]<<" ";
    }
    cout << endl<< "Adress using Pointer:" << s0.pointr;
    cout << endl<< "Normal int value:" << s0.a<<endl;

    return 0;
}
