
#include <iostream>
using namespace std;
class task1
{
	private:
	int temp;
	public:
	int warmer();
	int cooler();
	
	task1();
	
	
};
