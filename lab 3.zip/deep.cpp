#include "deep.h"
#include <iostream>
using namespace std;

complexNumber::complexNumber()
{
    //age =  variable;
    ch[0]='a';
    ch[1]='b';
    ch[2]='c';
    ch[3]='d';
    ch[4]='e';
    ch[5]='f';
    ch[6]='g';
    ch[7]='h';
    ch[8]='i';
    ch[9]='j';
}
complexNumber::complexNumber(complexNumber & gn)
{

}
