#include <iostream>
using namespace std;
class student
{
    public:
        int grades[7];
        string names[4];
        int a =20;
        int * pointr = & a;
        student();
        //void getting();
        //void printing();
};

