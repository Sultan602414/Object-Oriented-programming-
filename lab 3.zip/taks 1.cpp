#include "task1.h"
#include <iostream>
using namespace std;
int main(){
	task1 hd;
	int num;
	cout<<"ENTER 1 TO WARMER or 2 to COOLER";
	cin>>num;
	
	if (num==1){
		hd.warmer();
	}
	else if (num==2){
		hd.cooler();
	}
	else {
		cout<<"WRONG INPUT";
	}

}