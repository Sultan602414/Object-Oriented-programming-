#include <iostream>
using namespace std;

class parity
{
private:
    int sizee=1;
    int user;
    int arrays[];
    public:
        parity();
        void put();
        void printing();
        bool test();
        void delet();
        
};
