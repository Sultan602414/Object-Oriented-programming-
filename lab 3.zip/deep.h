#include <iostream>
using namespace std;


class complexNumber
{
private:



public:

    int variable = 27;
    int *age = & variable;
    int sizes=10;
    char ch[];
    //int arrays[sizes];
    complexNumber();
    complexNumber(complexNumber & gn);
    //void getting();
    //void printing();
};

