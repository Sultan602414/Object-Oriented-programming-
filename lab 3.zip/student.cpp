#include "student.h"
#include <iostream>
using namespace std;
student::student()
{
    grades[0] = 50;
    grades[1] = 70;
    grades[2] = 55;
    grades[3] = 46;
    grades[4] = 89;
    grades[5] = 33;
    grades[6] = 78;

    names[0] = "Tahir";
    names[0] = "Ali";
    names[0] = "jamshed";
    names[0] = "rizwan";
}

