#include <iostream>
#include "deep.h"
using namespace std;

int main()
{
    complexNumber CN,gn;

    for(int i=0;i<10;i++)
    {
        cout << CN.ch[i] << " ";
    }
    cout << endl;
    cout << "Pointer Adress : ";
    cout << CN.age;
    cout << endl << endl;
    cout << "Deep Copy"<< endl;
    for(int i=0;i<10;i++)
    {
        cout << gn.ch[i] << " ";
    }
    cout << endl;
    cout << "Pointer Adress : ";
    cout << gn.age;
    cout << endl << endl;
    CN.ch[0] = 'k';
    CN.ch[3] = 'm';
    CN.ch[5] = 't';
    CN.ch[9] = 'z';
    cout << "---------------------After Updating Array------------------------"<< endl << endl;
    for(int i=0;i<10;i++)
    {
        cout << CN.ch[i] << " ";
    }
    cout << endl;
    cout << "Pointer Adress : ";
    cout << CN.age;
    cout << endl << endl;
    cout << "Deep Copy"<< endl;
    for(int i=0;i<10;i++)
    {
        cout << gn.ch[i] << " ";
    }
    cout << endl;
    cout << "Pointer Adress : ";
    cout << gn.age;
    cout << endl << endl;
    return 0;
}
