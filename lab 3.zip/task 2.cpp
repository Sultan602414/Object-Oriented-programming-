#include <iostream>
#include "parity.h"
using namespace std;

int main()
{
    parity p;
    p.put();
    p.printing();
    p.delet();
    p.test();
    p.printing();
    cout<<p.test();
    
    return 0;
}
