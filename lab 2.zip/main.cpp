#include "employe.h";
#include<iostream>
using namespace std;

int main(){
	employe em;
	
	em.update();
	em.print();
	
}