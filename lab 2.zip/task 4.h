#include<iostream>
using namespace std;
class list
{
public:
    int max_size=100;
    int elements[100];
    int size1=0;
    bool empty_list()
    {
        return size1==0;
    }
    bool full_list()
    {
        return size1==max_size;
    }
    int search_list(int search_item)
    {
        for(int i=0;i<size1;i++)
        {
            if(elements[i]==search_item)
            {
                return i;
            }
            else
            {
                return -1;
            }

        }

    }
    int insert_list(int new_element)
    {
        if(!full_list())
        {
            elements[size1]=new_element;
            size1++;
        }
        else
        {
            cout<<"List full"<<endl;
        }
    }
    int remove_list(int remove_element)
    {
        int index=search_list(remove_element);
        if(index!=-1)
        {
            for(int i=index;i<size1-1;i++)
            {
                elements[i]=elements[i+1];
            }
            size1--;
        }
        else
        {
            cout<<"List full"<<endl;
        }
    }
    void print_list()
    {
        if(empty_list())
        {
            cout<<"List is empty";
        }
        else
        {
            for(int i=0;i<size1;i++)
            {
                cout<<elements[i]<<",";
            }

        }

    }

};