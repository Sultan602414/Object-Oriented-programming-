#ifndef COMPLEXNUMBER_H
#define COMPLEXNUMBER_H

#include<iostream>
using namespace std;

class complexNumber
{
	private:
		
	int real;
	int imag;
	int A[2];
	int B[2];
	
	public:
	
	int array_dec(){
		for(int i=0;i<4;i++){
			cout<<"REAL NUMBER: ";
			cin>>real;
			cout<<"imaginary NUMBER: ";
			cin>>imag;
			A[0]=real;
			A[1]=imag;
			B[i]=real + imag;
			
		}
		
	}
	
	void print(){
		for(int i=0;i<4;i++){
			cout<<B[i]<<" ";
		}
	}	
	
	
};

#endif