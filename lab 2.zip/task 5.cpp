#include <iostream>
#include "matrix.h"
 using namespace std;


int main() {
    int rows1, cols1, rows2, cols2;

    cout << "Enter dimensions for matrix 1 (rows columns): ";
    cin >> rows1 >> cols1;
    Matrix matrix1(rows1, cols1);

    cout << "Enter elements for matrix 1:\n";
    for (int i = 0; i < rows1; ++i) {
        for (int j = 0; j < cols1; ++j) {
            int element;
            cin >> element;
            matrix1.setElement(i, j, element);
        }
    }

    cout << "Matrix 1:\n";
    matrix1.print();

    cout << "Enter dimensions of matrix 2 (rows and columns): ";
    cin >> rows2 >> cols2;

    Matrix matrix2(rows2, cols2);

    cout << "Enter elements for matrix 2:\n";
    for (int i = 0; i < rows2; ++i) {
        for (int j = 0; j < cols2; ++j) {
            int element;
            cin >> element;
            matrix2.setElement(i, j, element);
        }
    }

    cout << "Matrix 2:\n";
    matrix2.print();


    int choice;
    cout << "Choose operation:\n";
    cout << "1. Addition\n";
    cout << "2. Subtraction\n";
    cout << "3. Multiplication\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
        case 1:
            if (!matrix1.canAdd(rows2, cols2)) {
                cout << "Matrices cannot be added due to different dimensions.\n";
            } else {
                matrix1.add(matrix2);
                cout << "Matrix addition performed successfully. Resultant matrix:\n";
                matrix1.display();
            }
            break;

        case 2:
            if (!matrix1.canSubtract(rows2, cols2)) {
                cout << "Matrices cannot be subtracted due to different dimensions.\n";
            } else {
                matrix1.subtract(matrix2);
                cout << "Matrix subtraction performed successfully. Resultant matrix:\n";
                matrix1.display();
            }
            break;

        case 3:
            if (!matrix1.canMultiply(rows2, cols2)) {
                cout << "Matrices cannot be multiplied due to incompatible dimensions.\n";
            } else {
                matrix1.multiply(matrix2);
                cout << "Matrix multiplication performed successfully. Resultant matrix:\n";
                matrix1.display();
            }
            break;

        default:
            cout << "Invalid choice.\n";
            break;
    }

    return 0;
}
