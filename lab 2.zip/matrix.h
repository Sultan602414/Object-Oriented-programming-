#include <iostream>
using namespace std;

const int MAX_ROWS = 10;
const int MAX_COLS = 10;

class Matrix {
private:
    int mat[MAX_ROWS][MAX_COLS];
    int rows;
    int cols;

public:
    Matrix(int r, int c) : rows(r), cols(c) {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                mat[i][j] = 0;
            }
        }
    }


    void setElement(int i, int j, int value) {
        mat[i][j] = value;
    }

    int getElement(int i, int j) {
        return mat[i][j];
    }

    bool isValid() {
        return rows > 0 && rows <= MAX_ROWS && cols > 0 && cols <= MAX_COLS;
    }


    void print() {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                cout << mat[i][j] << " ";
            }
            cout << "\n";
        }
    }



    // ... (Other member functions)

    bool canAdd(int otherRows, int otherCols) {
        return rows == otherRows && cols == otherCols;
    }

    bool canSubtract(int otherRows, int otherCols) {
        return rows == otherRows && cols == otherCols;
    }

    bool canMultiply(int otherRows, int otherCols) {
        return cols == otherRows;
    }

    void add(const Matrix& other) {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                mat[i][j] += other.mat[i][j];
            }
        }
    }

    void subtract(const Matrix& other) {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                mat[i][j] -= other.mat[i][j];
            }
        }
    }

    void multiply(const Matrix& other) {
        int result[MAX_ROWS][MAX_COLS];
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < other.cols; ++j) {
                result[i][j] = 0;
                for (int k = 0; k < cols; ++k) {
                    result[i][j] += mat[i][k] * other.mat[k][j];
                }
            }
        }

        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < other.cols; ++j) {
                mat[i][j] = result[i][j];
            }
        }
    }

    void display() const {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                cout << mat[i][j] << " ";
            }
            cout << "\n";
        }
    }
};
