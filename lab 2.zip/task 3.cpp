#include "strings.h";
#include<iostream>;
using namespace std;

int main(){
	int len1,len2;
	strings str;
	str.setvalue();
	str.print();
	str.maxlength();
	str.compare();
	str.searchChar();

}