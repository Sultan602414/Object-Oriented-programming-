#ifndef STRINGS_H
#define STRINGS_H
#include<iostream>
#include<string>
using namespace std;
class strings
{
	private:
		string first,second;
		
	public:
		
		void setvalue(){
			cout<<"ENRTER TWO NAMES: ";
			cin>>first>>second;	
		}
		void print(){
			cout<<first<<endl<<second;			
		}
		int maxlength(){
			int len1,len2;
			len1=first.size();
			len2=second.size();	
		//	cout<<len1<<" "<<len2;
		
			if(len1>len2){
        		cout<<endl<<first<<" has the max lenth";
			}
			else if(len1==len2){
				cout<<endl<<" BOTH ARE OF SAME LENGTH";
			}
			else{
				cout<<endl<<second<<" has the max lenth";
			}				
}
        int compare(){
        	int len1,len2;
        	len1=first.size();
			len2=second.size();	
        	
        	{ 
			int count=0;
			cout<<"\nComparing of both names";
			for (int i=0; i<=len1; i++)
			{
				if(first[i]!=second[i])
				{
					count = 1;
					break;
				}
			}
			if (count == 0)
			{
				cout<<"\nYour names are same";
			}
			else 
			{
				cout<<"\nyour names are different";
			}
		}
        	
        
		}
		void searchChar(){
			char ch;
			cout<< endl<<" enter the character ";
			cin>>ch;
			
		
			
			if(first.find(ch)<first.length()){ 
    cout<<endl<<" FOUNDED in first name";
} else {
    cout<<endl<<" NOT FOUNDED in first name";
}
		
if(second.find(ch)<second.length()){ 
    cout<<endl<<" FOUNDED in second name";
} else {
    cout<<endl<<" NOT FOUNDED in second game";
}		}

	
};

#endif