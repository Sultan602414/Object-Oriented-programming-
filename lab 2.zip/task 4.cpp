#include <iostream>
#include "task 4.h"
using namespace std;

int main()
{
    list Mymenu;
    int element,search_element,remove_element,pick;
    while(true)
    {
        cout<<"Menu"<<endl;
        cout<<"Press 1 to check List is Empty or not"<<endl;
        cout<<"Press 2 to check List is Full or not"<<endl;
        cout<<"Press 3 to insert element in list"<<endl;
        cout<<"Press 4 to remove element from list"<<endl;
        cout<<"Press 5 to search element from list"<<endl;
        cout<<"Press 6 to print the list"<<endl;
        cout<<"Exit"<<endl;
        cout<<"Pick option"<<endl;
        cin>>pick;
        switch(pick)
        {
        case 1:
            if(Mymenu.empty_list())
            {
                cout<<"Empty List"<<endl;
            }
            else
            {
                cout<<"Not Empty"<<endl;
            }
            break;
        case 2:
            if(Mymenu.full_list())
            {
                cout<<"Full list"<<endl;
            }
            else
            {
                cout<<"Not full"<<endl;
            }
            break;
        case 3:
            cout<<"Enter an element:";
            cin>>element;
            Mymenu.insert_list(element);
            break;
        case 4:
            cout<<"Enter element to remove:";
            cin>>remove_element;
            Mymenu.remove_list(remove_element);
            break;
        case 5:
            cout<<"Enter element to search:";
            cin>>search_element;
            if(Mymenu.search_list(search_element)!=-1)
            {
                cout<<"Element found in list"<<endl;
            }
            else
            {
                cout<<"Element not present"<<endl;
            }
            break;
        case 6:
            Mymenu.print_list();
            break;
        case 7:
            cout<<"Exit"<<endl;
            break;
        default:
            cout<<"Invalid"<<endl;
            break;
        }
    }
    return 0;
}