#ifndef EMPLOYE_H
#define EMPLOYE_H
#include<iostream>

using namespace std;

class employe
{
	private:
		string employe_name;
		int employe_phone_no;
		int employe_age,employe_no;
		float employe_compensation;
		
		
		
		
	public :
		int num[2];
		int age[2];
		int phone[2];
		float compen[2];
		string name[2];
		
		void update(){
			
			for(int i=0;i<2;i++){
			
			cout<<"Employe_no: ";
			cin>>employe_no;
			num[i]=employe_no;
			
			cout<<"Employe_name: ";
			cin>>employe_name;
			name[i]=employe_name;
			
			cout<<"Employe_phone: ";
			cin>>employe_phone_no;
			phone[i]=employe_phone_no;
			
			cout<<"Employe_age: ";
			cin>>employe_age;
			age[i]=employe_phone_no;
			
			cout<<"Employe_compensation: ";
			cin>>employe_compensation;
			compen[i]=employe_compensation;
			
		}
	}
		void print(){
			
			for(int i=0;i<2;i++){
				cout<<num[i]<<" "<<name[i]<<" "<<phone[i]<<" "<<age[i]<<" "<<compen[i]<<endl;
			}
			
		}
};

#endif