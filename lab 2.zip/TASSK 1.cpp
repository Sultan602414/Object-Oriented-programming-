#include<iostream>
using namespace std;
#include "complexNumber.h";


int main(){
	complexNumber CN;
	CN.array_dec();
	CN.print();
	
}


