#include <iostream>
using namespace std;
class bank_account{
	public:
		double acc_no, acc_balance,x;
		int acc;
		double z;
		
	
//		bank_account(){
//			acc_no=0;
//			acc_balance=0;
//		}
	
		int get_and_check_acc_no(){
			cout<<"ENTER THE ACOUNT NUMBER: "<<endl;
			cin>>acc_no;
			return acc_no;
			
		}
			int get_and_check_acc_balance(){
			cout<<"ENTER THE ACOUNT BALANCE: "<<endl;
			cin>>acc_balance;
			return acc_balance;
			
		}
		
		int deposit(){
			cout<<"ENTER THE AMMOUNT TO DEPOSIT: "<<endl;
			cin>>x;
			if (x>=0){
			acc_balance+=x;
		}
		else return acc_balance;
		}
		
		int  withdraw(){
			cout<<"ENTER THE AMMOUNT TO WITHDRAW: "<<endl;
			cin>>x;
			if (x>0 && x<acc_balance){
			acc_balance-=x;
		}
		else return acc_balance;
		}
		void print(){
			cout<<"THE ACC NO "<<acc_no<<" has current balance "<<acc_balance;
		}
		
		
};
class cheking_account : public bank_account{
	public:
	double interst_rate,min_balance,service_charges,post_interst;
	cheking_account(){
		cout<<"YOUR checking ACCOUNT: ";
		interst_rate=acc_balance*(2/100);
		min_balance=20000;
		service_charges=150;
		post_interst=acc_balance*(3/100);
	}
	
	int check_acc(){
		if(acc_balance<= min_balance){
			acc_balance=acc_balance-interst_rate-post_interst-service_charges;	
		}
		else{
			cout<<"YOUR ACCOUNT IS CHEKED AND ITS OK ";
		}
		return acc_balance;
	}
	

};
class saving_acc : public bank_account{
	public:
	double interst_rate,min_balance,service_charges,post_interst;
	saving_acc(){
		cout<<"YOUR SAVING ACCOUNT: ";
		interst_rate=acc_balance*(2/100);
		min_balance=2000;
		service_charges=150;
		post_interst=acc_balance*(3/100);
	}
	int save_check_acc(){
		if(acc_balance<= min_balance){
			int y;
			
			y=acc_balance+interst_rate+post_interst+service_charges;
			acc_balance=acc_balance-interst_rate-post_interst-service_charges;
				cout<<"YOUR savings are  "<<y;
		}
		else{
			cout<<"YOUR ACCOUNT IS CHEKED AND ITS OK ";
		}
		return acc_balance;
	}
	
};
	
int main(){
	
/*	bank_account ac;
	ac.get_and_check_acc_no();
	ac.get_and_check_acc_balance();	
	ac.deposit();
	ac.withdraw();
	ac.print();
	cout<<endl;
	*/
/*	
	cheking_account ac1;
	ac1.get_and_check_acc_no();
	ac1.get_and_check_acc_balance();
	ac1.acc_balance;
//	ac1.print();
	ac1.check_acc();
	cout<<endl;
//	ac1.print();
	ac1.withdraw();
	ac1.print();
	*/
	
	cout<<endl;
	saving_acc svc;
	
	cout<<endl;
	svc.get_and_check_acc_balance();

	svc.get_and_check_acc_no();
	cout<<endl;
	svc.save_check_acc();
	cout<<endl;
	
	svc.withdraw();
	svc.deposit();
	svc.print();
	
}
