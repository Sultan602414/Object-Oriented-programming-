#include<iostream>
#include<stdlib.h>
using namespace std;
class twoDarray {
	private:
		int arr[3][3];
		int arr2[3][3];
	
	public:
	void init(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				arr[i][j]=rand()%50;
			}	
		}
	}
	void print(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				cout<<arr[i][j]<<" ";
			}
			cout<<endl;
		}
	}
	void transpose(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				arr2[i][j]=arr[j][i];
			}
		}
		
		cout<<"THE TRANSPOSE IS: "<<endl;
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				cout<<arr2[i][j]<<" ";
			}
			cout<<endl;
		}
		
	}
	void is_symetric(){
		int count=0;
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(arr2[i][j]==arr[i][j]){
						
				}
					
			}
			
		}
		if(count=1){
			cout<<"no this is symetric matrix ";
		}
		else 
		cout<<"no this is not  symetric matrix ";
		
	}
		
	
};

int main(){
	
	twoDarray ar;
	ar.init();
	ar.print();
	cout<<endl;
	ar.transpose();
	cout<<endl;
	ar.is_symetric();
}
