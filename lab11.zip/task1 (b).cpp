#include<iostream>
using namespace std;
class myfather{
	protected:
	string name,eye_color,hair_color;
	void set_value(){
		name="DADDY";
		eye_color="brown";
		hair_color="grey";
	}
};
class mymother{
	protected:
	string name,eye_color,hair_color;
		void set_value(){
		name="MOM";
		eye_color="dark brown";
		hair_color="grey blakish";
	}
};
class myself:public myfather{
	public:
	int age;
	string education;
	void set_value(){
		name="SULTAN";
		eye_color="brown";
		hair_color="BLACK";
		age=20;
		education="bachelors";
	}
	void get_value(){
		cout<<"             myself"<<endl;
		cout<<name<<endl;
		cout<<eye_color<<endl;
		cout<<hair_color<<endl;
		cout<<education<<endl;
		cout<<age<<endl;
	}
};
class mysis:public mymother,public myfather{

		public:
	int age;
	string education;
	void set_value(){
		
		myfather::name="Sistrer";
		myfather::eye_color="green";
		myfather::hair_color="blackish brown";
		age=24;
		education="MAsters";
	}
	void get_value(){
	
		cout<<"              mysister"<<endl;
		
		cout<<myfather::name<<endl;
		cout<<myfather::eye_color<<endl;
		cout<<myfather::hair_color<<endl;
		cout<<education<<endl;
		cout<<age<<endl;
		cout<<"               myMOTHER"<<endl;
		mymother::set_value();
		cout<<mymother::name<<endl;
		cout<<mymother::eye_color<<endl;
		cout<<mymother::hair_color<<endl;
		cout<<"               myfaTHER"<<endl;
		myfather::set_value();
		cout<<myfather::name<<endl;
		cout<<myfather::eye_color<<endl;
		cout<<myfather::hair_color<<endl;
		
	}
};
int main(){
	mysis obj;
	myself my;
	my.set_value();
	my.get_value();
	obj.set_value();
	obj.get_value();
}
