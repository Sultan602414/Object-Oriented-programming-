#include <iostream>

using namespace std;

class Shapes {
protected:
    double length;
    double width;

public:
    Shapes(double l = 0.0, double w = 0.0) : length(l), width(w) {}

    void setLength(double l) {
        length = l;
    }

    double getLength() const {
        return length;
    }

    void setWidth(double w) {
        width = w;
    }

    double getWidth() const {
        return width;
    }

    virtual double area() const {
        return length * width;
    }

    virtual double volume() const {
        return 0.0;
    }
};

class TwoDShapes : public Shapes {
public:
    TwoDShapes(double l = 0.0, double w = 0.0) : Shapes(l, w) {}

    double area() const override {
        return Shapes::area();
    }
};

class ThreeDShapes : public Shapes {
public:
    ThreeDShapes(double l = 0.0, double w = 0.0) : Shapes(l, w) {}

    virtual double area() const override {
        return Shapes::area();
    }

    virtual double volume() const override {
        return Shapes::volume();
    }
};

class Circle : public TwoDShapes {
private:
    double radius;
    string color;

public:
    Circle(double r = 0.0, const string& c = "") : radius(r), color(c) {}

    void setRadius(double r) {
        radius = r;
    }

    double getRadius() const {
        return radius;
    }

    void setColor(const string& c) {
        color = c;
    }

    const string& getColor() const {
        return color;
    }

    double area() const override {
        return 3.14159265358979323846 * radius * radius;
    }
};

class Square : public TwoDShapes {
private:
    double side;
    string color;

public:
    Square(double s = 0.0, const string& c = "") : side(s), color(c) {}

    void setSide(double s) {
        side = s;
    }

    double getSide() const {
        return side;
    }

    void setColor(const string& c) {
        color = c;
    }

    const string& getColor() const {
        return color;
    }

    double area() const override {
        return side * side;
    }
};

class Cube : public ThreeDShapes {
private:
    double height;

public:
    Cube(double l = 0.0, double w = 0.0, double h = 0.0) : ThreeDShapes(l, w), height(h) {}

    void setHeight(double h) {
        height = h;
    }

    double getHeight() const {
        return height;
    }

    double area() const override {
        return 2 * (length * width + width * height + height * length);
    }

    double volume() const override {
        return length * width * height;
    }
};

class Pyramid : public ThreeDShapes {
private:
    double pyramidBase;
    double pyramidHeight;

public:
    Pyramid(double l = 0.0, double w = 0.0, double pb = 0.0, double ph = 0.0)
        : ThreeDShapes(l, w), pyramidBase(pb), pyramidHeight(ph) {}

    void setPyramidBase(double pb) {
        pyramidBase = pb;
    }

    double getPyramidBase() const {
        return pyramidBase;
    }

    void setPyramidHeight(double ph) {
        pyramidHeight = ph;
    }

    double getPyramidHeight() const {
        return pyramidHeight;
    }

    double area() const override {
        return length * width + 0.5 * pyramidBase * pyramidHeight;
    }

    double volume() const override {
        return (length * width * pyramidHeight) / 3;
    }
};

int main() {
    Circle circle(5.0, "Red");
    Square square(4.0, "Blue");
    Cube cube(3.0, 3.0, 3.0);
    Pyramid pyramid(4.0, 4.0, 5.0, 6.0);

    cout << "Circle Area: " << circle.area() << endl;
    cout << "Square Area: " << square.area() << endl;
    cout << "Cube Area: " << cube.area() << " Volume: " << cube.volume() << endl;
    cout << "Pyramid Area: " << pyramid.area() << " Volume: " << pyramid.volume() << endl;

    return 0;
}
