#include<iostream>
using namespace std;
class vehicle{
	protected:
		int no_of_tyre,no_of_seats;
		string type;
		void set_value(){
			no_of_tyre=4;
			no_of_seats=5;
			type="DAllA";
		}		
};
class car: public vehicle{
	protected:
	string color;
	
	
		void set_value(){
		vehicle::set_value();
			color="BLACK";
		}
};
class vitz: public car{
	protected:
	int model,plate_no;
	public:
		
		void set_value(){
		car::set_value();
			 model=2021;
			 plate_no=9597;
		}
	void print(){
		cout<<type<<endl;
		cout<<color<<endl;
		cout<<model<<endl;
		cout<<no_of_tyre<<endl;
		cout<<no_of_seats<<endl;
		cout<<plate_no<<endl;
		}
};
int main(){
	vitz vt;
	vt.set_value();
	vt.print();
	
}
