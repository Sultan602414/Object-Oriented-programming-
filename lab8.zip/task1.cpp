#include<iostream>
using namespace std;
class shape {
	public:

		shape(){
        cout<<" i am the shape "<<endl;
		}
        void draw(){
		        cout<<" DRAW the shape "<<endl;
		}
};
class circle : virtual public shape{
	public:
	circle(){
	 cout<<" i am  the circle "<<endl;
	}
	 void draw(){
        cout<<" DRAW the circle "<<endl;
        shape::draw();
		}

};
class rectangle : virtual public shape{
	public:
	    rectangle(){
   cout<<" i am the rectangle "<<endl;
	    }
	   void draw(){
        cout<<" DRAW the rectangle "<<endl;
        shape::draw();
		}

};
class square :virtual public circle , virtual public rectangle{
		public:
	square(){
	cout<<" i am the square "<<endl;
	}
	void draw(){
        cout<<" DRAW the square "<<endl;
        circle::draw();
		rectangle::draw();
		}

};
int main(){
	square sq;
	sq.draw();

}

