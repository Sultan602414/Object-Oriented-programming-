#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;

public:
    Employee(string& name, int id) : name(name), id(id) {}

    virtual double calculateSalary() {
        return 0.0;
    }

    void displayInfo() {
        cout << "Name: " << name << ", ID: " << id << endl;
    }
};

class Manager : public Employee {
private:
    double baseSalary;
    double bonus;

public:
    Manager(string& name, int id, double baseSalary, double bonus)
        : Employee(name, id), baseSalary(baseSalary), bonus(bonus) {}

    double calculateSalary() override {
        return baseSalary + bonus;
    }
};

class Developer : public Employee {
private:
    double hourlyRate;
    int hoursWorked;

public:
    Developer(string& name, int id, double hourlyRate, int hoursWorked)
        : Employee(name, id), hourlyRate(hourlyRate), hoursWorked(hoursWorked) {}

    double calculateSalary() override {
        return hourlyRate * hoursWorked;
    }
};

int main() {
    string johnDoe = "John Doe";
    string aliceSmith = "Alice Smith";
    string bobJohnson = "Bob Johnson";

    Employee employee(johnDoe, 101);
    Manager manager(aliceSmith, 201, 50000.0, 10000.0);
    Developer developer(bobJohnson, 301, 30.0, 40);

    cout << "Employee Information:" << endl;
    employee.displayInfo();
    cout << "Calculated Salary: $" << employee.calculateSalary() << endl;

    cout << "\nManager Information:" << endl;
    manager.displayInfo();
    cout << "Calculated Salary: $" << manager.calculateSalary() << endl;

    cout << "\nDeveloper Information:" << endl;
    developer.displayInfo();
    cout << "Calculated Salary: $" << developer.calculateSalary() << endl;

    return 0;
}
