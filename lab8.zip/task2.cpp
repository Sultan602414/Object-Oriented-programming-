#include <iostream>
using namespace std;

class Vehicle1
{
    private:
        string make;
        int model;
    public:
        Vehicle1()
        {
            make="BMW";
            model=2020;
        }
        void displyinfo()
        {
            cout<<"Make: "<<make<<endl;
            cout<<"Model: " <<model<<endl;
        }

};
class Car: public Vehicle1
{
private:
    string color;
    int N0_ofDoors;
public:
    Car()
    {
        color= "Black";
        N0_ofDoors=4;
    }
    void displyinfo()
    {
        Vehicle1::displyinfo();
        cout<<"Color of a car: "<<color<<endl;
        cout<<"Number of a Doors: "<<N0_ofDoors<<endl;
    }
};
class SportsCar: public Car
{
private:
    string Make;
    int top_speed;
public:
    SportsCar()
    {
        Make="Ferrari LaFerrari";
        top_speed=349;
    }
    displyinfo()
    {
        Car::displyinfo();
        cout<<"Sports Car Make: "<<Make<<endl;
        cout<<"Top Speed of "<<Make<<" is "<<top_speed<<"km/h"<<endl;
    }
};
int main()
{
    Vehicle1 V;
    Car C;
    SportsCar S;
    cout<<"By instance: "<<endl;
    cout<<"Vehicle info: "<<endl;
    V.displyinfo();
    cout<<endl<<"Car: "<<endl;
    C.displyinfo();
    cout<<endl<<"Sports Car info "<<endl;
    S.displyinfo();
    cout<<endl<<endl<<endl;
    cout<<"Overridden Class Function: "<<endl;
    S.displyinfo();

}
